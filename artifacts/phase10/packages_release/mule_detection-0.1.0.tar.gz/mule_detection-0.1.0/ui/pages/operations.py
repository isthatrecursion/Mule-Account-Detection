"""Durable intake/model jobs, with no local model or dataset processing."""

import json
from uuid import UUID

import streamlit as st

from ui.components.actions import send
from ui.state import Workspace

FINDINGS = {
    "SCHEMA_HEADER": "CSV columns do not match the registered source schema.",
    "CHECKSUM_MISMATCH": "The file bytes do not match the declared checksum.",
    "INTAKE_METADATA_CONFLICT": "These file bytes already have different registered scope or provenance.",
    "CONFOUNDED_RESEARCH_COHORTS": "Research cohorts and labels are confounded; qualified use remains blocked.",
    "UNVERIFIED_RESEARCH_PROVENANCE": "Research provenance is unverified.",
    "QUALIFIED_SOURCE_NOT_CERTIFIED": "The source is not certified for qualified use.",
}


def render(workspace: Workspace) -> None:
    config = workspace.api.config
    st.header("Intake & operations")
    st.caption(
        f"Workspace limits: {config.max_upload_bytes:,} upload bytes · {config.max_batch_rows:,} rows. API validation is authoritative."
    )
    disabled = bool(
        workspace.pending and workspace.pending.state in {"PENDING", "UNKNOWN", "CONFLICT"}
    )
    if workspace.allowed("batch:intake"):
        with st.form("intake"):
            source = st.file_uploader("Feature batch CSV", type=["csv"])
            manifest = st.file_uploader("Declared batch manifest JSON", type=["json"])
            if st.form_submit_button("Submit batch", disabled=disabled):
                if source is None or manifest is None:
                    st.error("Choose both a CSV batch and its declared manifest.")
                elif source.size > config.max_upload_bytes or manifest.size > 16384:
                    st.error("The selected upload exceeds the workspace limits.")
                else:
                    try:
                        declaration = json.loads(manifest.getvalue())
                        if not isinstance(declaration, dict):
                            raise ValueError()
                        declared = json.dumps(declaration, ensure_ascii=True, separators=(",", ":"))
                        if len(declared) > 16384:
                            raise ValueError()
                    except (ValueError, UnicodeError):
                        st.error("Choose a valid manifest JSON object within the metadata limit.")
                    else:
                        workspace.begin(
                            "Batch intake",
                            "/v1/batches",
                            None,
                            content=source.getvalue(),
                            manifest=declared,
                            filename=source.name,
                        )
                        send(workspace)
                        st.rerun()
    if workspace.allowed("score:submit") or workspace.allowed("train:submit"):
        with st.form("model_job"):
            choices = [
                name
                for name, p in (("Scoring", "score:submit"), ("Training", "train:submit"))
                if workspace.allowed(p)
            ]
            operation = st.selectbox("Job type", choices)
            batch = st.text_input("Accepted batch ID")
            bundle = st.text_input("Approved immutable bundle digest (scoring only)", max_chars=64)
            if st.form_submit_button("Submit job", disabled=disabled):
                try:
                    payload = {"batch_id": str(UUID(batch))}
                    if operation == "Scoring":
                        if len(bundle) != 64 or any(c not in "0123456789abcdef" for c in bundle):
                            raise ValueError()
                        payload["bundle_digest"] = bundle
                except ValueError:
                    st.error("Enter a valid accepted batch ID and, for scoring, bundle digest.")
                else:
                    path = "/v1/scoring-runs" if operation == "Scoring" else "/v1/training-runs"
                    workspace.begin(operation, path, payload)
                    send(workspace)
                    st.rerun()
    st.subheader("Durable jobs")
    with st.form("reconnect_job"):
        identity = st.text_input("Reconnect to job ID", value=str(st.query_params.get("job", "")))
        if st.form_submit_button("Reconnect"):
            try:
                value = str(UUID(identity))
                if value not in workspace.jobs:
                    workspace.jobs.append(value)
                st.query_params["job"] = value
            except ValueError:
                st.error("Enter a valid job ID.")
    for job_id in workspace.jobs[-20:]:
        job = workspace.poll(job_id)
        st.text("Job " + job_id + " · " + job["kind"] + " · " + job["state"])
        st.query_params["job"] = job_id
        result = job.get("result") or {}
        if result.get("batch_id"):
            st.text("Batch: " + str(result["batch_id"]))
        if result.get("outcome"):
            st.text("Validation: " + str(result["outcome"]))
        for code in result.get("finding_codes", []):
            st.warning(
                "Validation finding: "
                + str(code)
                + " — "
                + FINDINGS.get(
                    str(code),
                    "Check the registered source and manifest before submitting corrected data.",
                )
            )
        if result.get("error_code"):
            st.error("Job failed. An authorized operator can retry after resolving the dependency.")
        if st.button("Refresh job status", key="poll_" + job_id):
            workspace.poll(job_id)  # Poll interval remains enforced even after repeated clicks.
        if workspace.allowed("job:retry") and job["state"] == "FAILED":
            with st.form("retry_" + job_id):
                reason = st.text_input("Retry reason", max_chars=200)
                if st.form_submit_button("Request authorized retry", disabled=disabled):
                    if reason.strip():
                        workspace.begin(
                            "Job retry", f"/v1/jobs/{UUID(job_id)}/retry", {"reason": reason}
                        )
                        send(workspace)
                        st.rerun()
                    else:
                        st.error("Enter a reason for retrying.")
