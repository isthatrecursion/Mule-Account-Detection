"""Permission-aware API views."""
