"""Audited export authorization followed by actor-scoped, expiring download."""

from uuid import UUID

import streamlit as st

from ui.components.actions import send
from ui.state import Workspace


def render(workspace: Workspace) -> None:
    st.header("Authorized exports")
    st.caption(
        "Exports capture the selected queue and case state at authorization. Downloads expire after ten minutes."
    )
    with st.form("export_queue"):
        queue = st.text_input("Queue version to export", value=workspace.queue_version or "")
        columns = ["case_id", "rank", "raw_score", "state"]
        if workspace.allowed("export:sensitive"):
            columns += ["record_key", "note"]
        selected = st.multiselect(
            "Columns", columns, default=["case_id", "rank", "raw_score", "state"]
        )
        reason = st.text_input("Export reason", max_chars=200)
        disabled = bool(
            workspace.pending and workspace.pending.state in {"PENDING", "UNKNOWN", "CONFLICT"}
        )
        if st.form_submit_button("Authorize export", disabled=disabled):
            try:
                identity = str(UUID(queue))
                if not reason.strip() or not selected:
                    raise ValueError()
            except ValueError:
                st.error("Choose a queue version, at least one column and a reason.")
            else:
                workspace.begin(
                    "Export",
                    "/v1/exports",
                    {"queue_version": identity, "columns": selected, "reason": reason},
                )
                send(workspace)
                st.rerun()
    for job_id in workspace.jobs[-20:]:
        job = workspace.poll(job_id)
        if job["kind"] != "export":
            continue
        st.text("Export " + job_id + " · " + job["state"])
        if job["state"] == "SUCCEEDED" and st.button(
            "Fetch authorized download", key="fetch_" + job_id
        ):
            data = workspace.api.request(
                "GET", f"/v1/exports/{UUID(job_id)}/download", download=True
            )
            st.download_button(
                "Download CSV",
                data=data,
                file_name="review-" + job_id + ".csv",
                mime="text/csv",
                key="download_" + job_id,
            )
