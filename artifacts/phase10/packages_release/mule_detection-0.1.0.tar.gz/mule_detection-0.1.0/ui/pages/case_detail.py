"""Factual evidence only: anonymous features never become invented business narratives."""

from uuid import UUID

import streamlit as st

from ui.components.actions import review_forms
from ui.components.freshness import display_score
from ui.components.freshness import render as render_freshness
from ui.state import Workspace


def render(workspace: Workspace) -> None:
    st.header("Case evidence")
    raw = st.text_input(
        "Case ID", value=workspace.selected_case or str(st.query_params.get("case", ""))
    )
    try:
        identity = UUID(raw)
    except ValueError:
        st.info("Open a case from the queue or enter a case ID.")
        return
    workspace.selected_case = str(identity)
    case = workspace.api.case(identity)  # Mutable workflow version is always fresh.
    score = case["score"]
    st.subheader("Selected assessment")
    render_freshness(score)
    if score.get("data_tier") == "research":
        st.warning(
            "Research demonstration. Cohort/target confounding remains unresolved. Feature meanings are unverified."
        )
    st.metric("Model review priority (raw)", display_score(score))
    st.text(
        "Rank: "
        + str(score.get("rank") or "—")
        + " · Percentile: "
        + str(score.get("percentile") if score.get("percentile") is not None else "—")
    )
    for label, key in (
        ("Selected score", "score_id"),
        ("Model", "model_id"),
        ("Bundle", "bundle_digest"),
        ("Batch", "batch_id"),
        ("Policy", "policy_hash"),
        ("Dictionary", "dictionary_version"),
        ("Feature snapshot", "snapshot_id"),
        ("Queue", "queue_version"),
    ):
        st.text(label + ": " + str(case.get(key) or "Not supplied"))
    for limitation in score.get("provenance_limitations") or []:
        st.text(str(limitation))
    if case.get("newer_assessment_available"):
        st.info("A newer assessment exists. This case retains the score and evidence shown above.")
        st.text("Newer score: " + str(case.get("newer_score_id")))
        if st.button("Inspect assessment history"):
            st.session_state["navigate_to"] = "History"
            st.rerun()
    evidence = workspace.cache.read(
        workspace.fingerprint,
        "evidence",
        case["score_id"],
        {},
        workspace.api.config.cache_seconds,
        lambda: workspace.api.evidence(identity),
    )
    facts = evidence.get("facts")
    if not facts:
        st.info("Detailed contributions are unavailable for this selected assessment.")
    else:
        st.subheader("Observed model evidence")
        st.caption(
            "Contributions describe model associations, not causation, criminal intent or certified banking behavior."
        )
        st.text("Contribution scale: " + str(facts.get("scale") or "Unknown"))
        st.text(
            "Base: "
            + str(facts.get("base_value"))
            + " · Raw margin: "
            + str(facts.get("raw_margin"))
        )
        values = [
            {
                "Feature": f["raw_feature"],
                "Meaning": f.get("meaning_status", "UNVERIFIED"),
                "Observed value": str(f.get("observed_value"))
                if f.get("observed_value") is not None
                else "—",
                "Value status": f.get("value_status"),
                "Signed contribution": f.get("contribution"),
                "Training reference percentile": f.get("reference_percentile"),
                "Training category frequency": f.get("category_frequency"),
                "Unseen category": f.get("unseen_category"),
            }
            for f in facts.get("raw_aggregates", [])
        ]
        st.table(values, hide_index=True, width="stretch")
    st.subheader("Review workflow")
    st.text("State: " + case["state"] + " · Version: " + str(case["case_version"]))
    st.text("Assignee: " + str(case.get("assignee") or "Unassigned"))
    review_forms(workspace, case)
