"""API-filtered immutable histories; sensitive text is rendered as text, never HTML."""

from uuid import UUID

import streamlit as st

from ui.state import Workspace


def render(workspace: Workspace) -> None:
    st.header("Assessment & review history")
    value = st.text_input(
        "Case ID for history", value=workspace.selected_case or str(st.query_params.get("case", ""))
    )
    try:
        identity = UUID(value)
    except ValueError:
        st.info("Select a case to view its immutable history.")
        return
    workspace.selected_case = str(identity)
    kinds = (["reviews", "scores"] if workspace.allowed("case:read") else []) + (
        ["audit"] if workspace.allowed("audit:read") else []
    )
    kind = st.selectbox("History type", kinds)
    offset_key = str(identity) + ":" + kind
    after = workspace.history_after.get(offset_key, 0)
    page = workspace.api.history(identity, kind, after)
    st.caption("Earlier events retain their original assessment. Later corrections append history.")
    for event in page["items"]:
        with st.container(border=True):
            for key in (
                "created_at",
                "event_id",
                "score_id",
                "model_id",
                "case_version",
                "version",
                "queue_version",
                "action",
                "actor_id",
                "conclusion",
                "rank",
                "raw_score",
                "freshness",
                "assessed_as_of",
            ):
                if key in event:
                    st.text(key.replace("_", " ") + ": " + str(event[key]))
            if event.get("selected"):
                st.caption("Selected assessment for the opened case.")
            elif kind == "scores" and event.get("queue_version"):
                if st.button(
                    "Inspect queue version " + str(event["version"]),
                    key="history_queue_" + event["score_id"],
                ):
                    workspace.choose_queue(event["queue_version"])
                    st.session_state["navigate_to"] = "Review queue"
                    st.rerun()
            if "note" in event:
                st.text(
                    ("Reopen reason: " if event.get("action") == "case:reopen" else "Review note: ")
                    + event["note"]
                )
            elif event.get("action") == "case:reopen":
                st.caption("A reason is unavailable in this API response or was not recorded.")
    if kind == "scores" and len(page["items"]) > 1:
        st.caption(
            "Compare published ranks and raw priorities above. Different model versions may use different score scales; changes do not establish changed criminal behavior."
        )
    left, right = st.columns(2)
    if left.button("Earlier history", disabled=after == 0):
        workspace.history_after[offset_key] = max(0, after - 20)
        st.rerun()
    if right.button("Later history", disabled=page.get("next") is None):
        workspace.history_after[offset_key] = page["next"]
        st.rerun()
