"""Pinned queue pages; reconciliation never silently changes the selected assessment."""

from typing import Any
from uuid import UUID

import streamlit as st

from ui.state import Workspace


def render(workspace: Workspace) -> None:
    st.header("Review queue")
    heads = workspace.api.queues().get("items", [])
    if not heads:
        st.info("No published queue is available in your current scope.")
        return
    if workspace.queue_version is None:
        workspace.choose_queue(heads[0]["queue_version"], heads[0]["cohort_id"])
    version = workspace.queue_version
    assert version is not None
    options = {
        v["queue_version"]: f"Cohort {v['cohort_id'][:8]} · version {v['version']}" for v in heads
    }
    if version not in options:
        options[version] = "Opened historical queue · " + version[:8]
    selected = st.selectbox(
        "Published queue version",
        list(options),
        index=list(options).index(version),
        format_func=lambda value: options[value],
    )
    if selected != workspace.queue_version:
        head: dict[str, Any] = next((h for h in heads if h["queue_version"] == selected), {})
        workspace.choose_queue(selected, head.get("cohort_id"))
    version = workspace.queue_version
    assert version is not None
    newest = next((h for h in heads if h["cohort_id"] == workspace.queue_cohort), None)
    if newest and newest["queue_version"] != workspace.queue_version:
        st.info("A newer queue is available. This view still uses the opened version.")
        if st.button("Open newer queue", key="new_queue"):
            workspace.choose_queue(newest["queue_version"], newest["cohort_id"])
            st.rerun()
    state = st.selectbox(
        "Case state filter", ["All", "QUEUED", "ASSIGNED", "IN_REVIEW", "REVIEWED"]
    )
    assignee = st.text_input("Assignee filter (actor ID)", max_chars=100)
    limit = st.selectbox("Page size", [10, 25, 50, 100], index=1)
    filters = {
        "state": None if state == "All" else state,
        "assignee": assignee or None,
        "limit": limit,
    }
    signature = str(filters)
    if st.session_state.get("queue_filters") != signature:
        workspace.cursor, workspace.previous_cursors = {}, []
        st.session_state["queue_filters"] = signature
    params = {**filters, **workspace.cursor}
    page = workspace.cache.read(
        workspace.fingerprint,
        "queue",
        version,
        params,
        workspace.api.config.cache_seconds,
        lambda: workspace.api.queue(UUID(version), **params),
    )
    st.caption(
        f"Pinned queue {page['queue_version']} · {page['total']} matching cases · model {page.get('model_version') or 'Unknown'}"
    )
    st.caption(
        "Raw score is model review priority, not a percent chance or legal conclusion. Percentile describes full-cohort rank."
    )
    rows = [
        {
            "Rank": v["rank"],
            "Percentile": v.get("percentile"),
            "Review priority (raw)": v["raw_score"],
            "Case": v["case_id"],
            "Assignee": v.get("assignee") or "Unassigned",
            "State": v["state"],
            "Freshness": v["freshness"],
            "Model version": page.get("model_version"),
        }
        for v in page["items"]
    ]
    st.table(rows, hide_index=True, width="stretch")
    if page["items"]:
        case = st.selectbox("Case to open", [v["case_id"] for v in page["items"]])
        if st.button("Open case", key="open_case"):
            workspace.selected_case = case
            st.query_params["case"] = case
            st.session_state["navigate_to"] = "Case evidence"
            st.rerun()
    left, right = st.columns(2)
    if left.button("Previous page", disabled=not workspace.previous_cursors):
        workspace.cursor = workspace.previous_cursors.pop()
        st.rerun()
    if right.button("Next page", disabled=page.get("next") is None):
        workspace.previous_cursors.append(dict(workspace.cursor))
        workspace.cursor = page["next"]
        st.rerun()
