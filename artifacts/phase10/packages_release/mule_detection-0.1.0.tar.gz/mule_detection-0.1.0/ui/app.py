"""Streamlit entrypoint. Rendering is driven entirely by authenticated API responses."""

from pathlib import Path

import streamlit as st

from ui import runtime
from ui.api_client import MESSAGES, ApiFailure
from ui.auth import LoginRequired
from ui.components.actions import pending
from ui.config import UiConfig, UiConfigurationError
from ui.pages import case_detail, exports, history, operations, queue
from ui.state import Workspace


def render() -> None:
    st.set_page_config(page_title="Evidence Review", page_icon="◈", layout="wide")
    st.title("Evidence Review")
    st.caption("ANALYST WORKSPACE · MODEL REVIEW PRIORITY · HUMAN DECISIONS")
    if st.session_state.get("logged_out"):
        st.info("You are signed out. Sign in through the organization’s identity gateway.")
        try:
            st.link_button("Sign in", UiConfig.load(Path.cwd()).login_url)
        except UiConfigurationError:
            st.caption("The identity integration is awaiting protected deployment configuration.")
        return
    workspace: Workspace | None = st.session_state.get("workspace")
    try:
        if workspace is None:
            workspace = runtime.create_workspace()
            st.session_state["workspace"] = workspace
            st.session_state["handle_fingerprint"] = runtime.handle_fingerprint()
        elif st.session_state.get("handle_fingerprint") != runtime.handle_fingerprint():
            raise LoginRequired()
        old = workspace.fingerprint
        workspace.authenticate()
        if old and old != workspace.fingerprint:
            st.session_state.clear()
            st.session_state["workspace"] = workspace
            st.session_state["handle_fingerprint"] = runtime.handle_fingerprint()
            st.rerun()
        st.sidebar.caption("Authenticated API session")
        st.sidebar.text(workspace.identity["actor_id"][:21] + "…")
        if st.sidebar.button("Sign out", key="logout"):
            workspace.logout()
            st.session_state.clear()
            st.session_state["logged_out"] = True
            st.query_params.clear()
            st.rerun()
        choices = {}
        if workspace.allowed("queue:read"):
            choices["Review queue"] = queue.render
        if workspace.allowed("case:read"):
            choices["Case evidence"] = case_detail.render
        if workspace.allowed("case:read") or workspace.allowed("audit:read"):
            choices["History"] = history.render
        if any(
            workspace.allowed(p)
            for p in ("batch:intake", "score:submit", "train:submit", "job:read")
        ):
            choices["Operations"] = operations.render
        if workspace.allowed("export:create"):
            choices["Exports"] = exports.render
        if not choices:
            st.warning("This identity has no workspace actions in its current API scope.")
            return
        target = st.session_state.pop("navigate_to", None)
        if target in choices:
            st.session_state["page"] = target
        if st.session_state.get("page") not in choices:
            st.session_state["page"] = next(iter(choices))
        page = st.sidebar.radio("Workspace", list(choices), key="page")
        pending(workspace)
        if workspace.last_result:
            result = workspace.last_result
            st.caption(
                "Last persisted action: "
                + str(result.get("event_id") or result.get("job_id") or "Acknowledged")
            )

        @st.fragment(
            run_every=workspace.api.config.poll_seconds
            if page in {"Operations", "Exports"}
            else None
        )
        def content() -> None:
            assert workspace is not None
            try:
                before = workspace.fingerprint
                workspace.authenticate()
                if before != workspace.fingerprint:
                    st.session_state.clear()
                    st.session_state["workspace"] = workspace
                    st.session_state["handle_fingerprint"] = runtime.handle_fingerprint()
                    st.rerun()
                choices[page](workspace)
            except ApiFailure as error:
                st.error(MESSAGES[error.code])
                if error.request_id:
                    st.caption("Request reference: " + error.request_id)
            except LoginRequired:
                workspace.logout()
                st.session_state.clear()
                st.session_state["logged_out"] = True
                st.query_params.clear()
                st.rerun()
            except Exception:
                st.error("The API returned an unexpected response. Reload this view.")

        content()
    except UiConfigurationError:
        st.warning(
            "Workspace configuration is incomplete. Shared login is blocked until organization identity settings are supplied."
        )
        st.info(
            "Contact the deployment owner to configure the API and approved per-user token gateway."
        )
    except LoginRequired:
        if workspace:
            workspace.logout()
        st.session_state.clear()
        st.session_state["logged_out"] = True
        st.query_params.clear()
        st.rerun()
    except ApiFailure as error:
        if workspace:
            workspace.cache.clear()
        st.error(MESSAGES[error.code])
        if error.request_id:
            st.caption("Request reference: " + error.request_id)


if __name__ == "__main__":
    render()
