# Analyst workspace

Phase 10 implements the Streamlit client through authenticated FastAPI contracts. Page modules never load models or query PostgreSQL. See [setup and workflow](../docs/workspace.md), [gateway identity contract](../docs/identity_flow.md) and [verification](../docs/acceptance/phase10_readiness.md).

Install the platform `requirements-ui-*.lock`, install this package, then run `python -m ui.launcher --root <project-directory>`. Normal startup requires protected `secrets/ui.json`; the incomplete example intentionally fails closed. No shared demo identity or token-paste flow is available.
