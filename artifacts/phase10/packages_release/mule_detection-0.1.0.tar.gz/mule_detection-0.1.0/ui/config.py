"""Protected deployment configuration. Browser state cannot select endpoints or trust."""

from pathlib import Path
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator


class UiConfigurationError(Exception):
    def __str__(self) -> str:
        return "Workspace startup requires API and identity gateway configuration."


class UiConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, hide_input_in_errors=True)
    environment: str = "research"
    api_base_url: str
    api_issuer: str
    api_audience: str = Field(min_length=1)
    gateway_url: str
    gateway_issuer: str
    gateway_audience: str
    gateway_jwks_url: str
    gateway_service_token: SecretStr
    login_url: str
    max_upload_bytes: int = Field(default=134217728, gt=0, le=2147483648)
    max_batch_rows: int = Field(default=100000, gt=0, le=1000000)
    poll_seconds: int = Field(default=5, ge=3, le=60)
    cache_seconds: int = Field(default=5, ge=1, le=15)

    @model_validator(mode="after")
    def trust(self) -> "UiConfig":
        for name in (
            "api_base_url",
            "api_issuer",
            "gateway_url",
            "gateway_issuer",
            "gateway_jwks_url",
            "login_url",
        ):
            url = urlsplit(getattr(self, name))
            local_api = (
                name == "api_base_url"
                and self.environment in {"local", "test", "research"}
                and url.hostname in {"127.0.0.1", "localhost", "::1"}
                and url.scheme == "http"
            )
            if (
                not url.hostname
                or url.username
                or url.password
                or url.fragment
                or url.query
                or url.scheme != "https"
                and not local_api
            ):
                raise ValueError("Trusted HTTPS endpoints are required")
        if len(self.gateway_service_token.get_secret_value()) < 32:
            raise ValueError("A protected gateway service credential is required")
        if self.environment not in {"local", "test", "research", "staging", "qualified"}:
            raise ValueError("Unsupported workspace environment")
        return self

    @classmethod
    def load(cls, root: Path) -> "UiConfig":
        try:
            return cls.model_validate_json((root / "secrets/ui.json").read_bytes())
        except Exception:
            raise UiConfigurationError() from None
