"""Bounded HTTP-only client. No response error text or raw exceptions reach the UI."""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

import httpx

from ui.auth import LoginRequired, UserTokenProvider, effective_identity
from ui.config import UiConfig


class ApiFailure(Exception):
    def __init__(self, code: str, *, status: int = 0, request_id: str | None = None) -> None:
        self.code, self.status, self.request_id = code, status, request_id
        super().__init__(code)


MESSAGES = {
    "UNAVAILABLE": "The API is unavailable. Your pending action is retained; its outcome is unknown.",
    "DENIED": "Your current API permissions do not allow this action.",
    "NOT_FOUND": "This item is unavailable in your current scope.",
    "CONFLICT": "The case or request changed. Review the latest state before a new action.",
    "INVALID": "The API rejected this request. Check the required fields and upload limits.",
}


class ApiClient:
    def __init__(
        self, config: UiConfig, provider: UserTokenProvider, *, client: httpx.Client | None = None
    ) -> None:
        self.config, self.provider = config, provider
        self._client = client or httpx.Client(
            base_url=config.api_base_url.rstrip("/"),
            timeout=httpx.Timeout(20, connect=3, write=60),
            verify=True,
            follow_redirects=False,
            trust_env=False,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        payload: dict[str, Any] | None = None,
        key: UUID | None = None,
        content: bytes | None = None,
        manifest: str | None = None,
        filename: str | None = None,
        params: dict[str, Any] | None = None,
        download: bool = False,
    ) -> Any:
        if (
            not path.startswith("/v1/")
            or any(v in path for v in ("..", "?", "#", "//"))
            or method not in {"GET", "POST"}
            or method == "POST"
            and key is None
        ):
            raise ValueError("A supported API operation and write identity are required")
        credential = self.provider.credential()
        request_id = str(uuid4())
        headers = {
            "Authorization": "Bearer " + credential.token.get_secret_value(),
            "X-Request-ID": request_id,
        }
        if key:
            headers["Idempotency-Key"] = str(key)
        if content is not None:
            headers.update(
                {
                    "Content-Type": "application/octet-stream",
                    "X-Batch-Manifest": manifest or "{}",
                    "X-Filename": filename or "upload.csv",
                }
            )
        try:
            with self._client.stream(
                method, path, json=payload, content=content, headers=headers, params=params
            ) as response:
                maximum = 16777216 if download else 4194304
                parts, count = [], 0
                for chunk in response.iter_bytes():
                    count += len(chunk)
                    if count > maximum:
                        raise ApiFailure("UNAVAILABLE", request_id=request_id)
                    parts.append(chunk)
                response_id = response.headers.get("X-Request-ID", request_id)
                try:
                    response_id = str(UUID(response_id))
                except ValueError:
                    response_id = request_id
                if response.status_code == 401:
                    raise LoginRequired()
                codes = {
                    403: "DENIED",
                    404: "NOT_FOUND",
                    409: "CONFLICT",
                    413: "INVALID",
                    415: "INVALID",
                    422: "INVALID",
                }
                if not 200 <= response.status_code < 300:
                    raise ApiFailure(
                        codes.get(response.status_code, "UNAVAILABLE"),
                        status=response.status_code,
                        request_id=response_id,
                    )
                body = b"".join(parts)
                if download:
                    return body
                import json

                value = json.loads(body)
                if not isinstance(value, dict):
                    raise ApiFailure("UNAVAILABLE", request_id=response_id)
                return value
        except (ApiFailure, LoginRequired):
            raise
        except Exception:
            raise ApiFailure("UNAVAILABLE", request_id=request_id) from None

    def json(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        value = self.request(method, path, **kwargs)
        if not isinstance(value, dict):
            raise ApiFailure("UNAVAILABLE")
        return value

    def me(self) -> dict[str, Any]:
        credential = self.provider.credential()
        return effective_identity(self.json("GET", "/v1/me"), credential)

    def queues(self) -> dict[str, Any]:
        return self.json("GET", "/v1/queues")

    def queue(self, version: UUID, **filters: Any) -> dict[str, Any]:
        if set(filters) - {"limit", "state", "assignee", "after_rank", "after_key"}:
            raise ValueError("Unsupported queue filter")
        return self.json(
            "GET",
            f"/v1/queues/{version}/cases",
            params={k: v for k, v in filters.items() if v is not None},
        )

    def case(self, case_id: UUID) -> dict[str, Any]:
        return self.json("GET", f"/v1/cases/{case_id}")

    def evidence(self, case_id: UUID) -> dict[str, Any]:
        return self.json("GET", f"/v1/cases/{case_id}/evidence")

    def history(self, case_id: UUID, kind: str, after: int = 0) -> dict[str, Any]:
        return self.json(
            "GET",
            f"/v1/cases/{case_id}/history",
            params={"kind": kind, "after": after, "limit": 20},
        )

    def job(self, job_id: UUID) -> dict[str, Any]:
        return self.json("GET", f"/v1/jobs/{job_id}")
