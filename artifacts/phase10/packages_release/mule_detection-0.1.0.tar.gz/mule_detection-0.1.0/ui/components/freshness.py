"""Freshness is independent of score magnitude and understandable without color."""

from typing import Any

import streamlit as st

LABELS = {
    "COMPLETE": "Complete assessment — required source coverage is complete.",
    "BUFFERING": "Buffering — late or incomplete source data is awaiting reconciliation.",
    "PROVISIONAL_HIGHER": "Provisional escalation — pending reconciliation; retained complete assessment remains authoritative.",
    "STALE": "Stale assessment — its original cutoff is retained; freshness is not established.",
    "UNAVAILABLE": "Assessment unavailable — no usable published score. This does not mean low priority.",
}


def freshness_text(state: str, cutoff: Any = None) -> str:
    return (
        LABELS.get(state, LABELS["UNAVAILABLE"])
        + " Assessed as of: "
        + str(cutoff or "Unknown")
        + "."
    )


def render(score: dict[str, Any]) -> None:
    state = str(score.get("freshness") or "UNAVAILABLE")
    message = freshness_text(state, score.get("assessed_as_of"))
    (st.info if state == "COMPLETE" else st.warning)(message)
    st.caption("Source completeness: " + str(score.get("completeness") or "UNKNOWN"))
    if score.get("source_coverage"):
        st.table(score["source_coverage"], hide_index=True, width="stretch")
    if state == "PROVISIONAL_HIGHER":
        st.text(
            "Authoritative baseline score: " + str(score.get("baseline_score_id") or "Not supplied")
        )


def display_score(score: dict[str, Any]) -> str:
    value = score.get("raw_score")
    return "—" if value is None or score.get("freshness") == "UNAVAILABLE" else f"{value:.6g}"
