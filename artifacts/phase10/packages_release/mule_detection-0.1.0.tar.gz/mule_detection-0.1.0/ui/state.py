"""Per-session state: bound read cache, pinned navigation and explicit pending writes."""

from __future__ import annotations

import copy
import hashlib
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from ui.api_client import ApiClient, ApiFailure
from ui.auth import LoginRequired


@dataclass
class PendingWrite:
    action: str
    path: str
    payload: dict[str, Any] | None
    fingerprint: str
    key: UUID = field(default_factory=uuid4)
    content: bytes | None = field(default=None, repr=False)
    manifest: str | None = None
    filename: str | None = None
    state: str = "PENDING"
    result: dict[str, Any] | None = None
    latest: dict[str, Any] | None = None


class SessionCache:
    def __init__(self) -> None:
        self._values: dict[str, tuple[float, Any]] = {}

    def read(
        self,
        fingerprint: str,
        endpoint: str,
        version: str,
        filters: dict[str, Any],
        seconds: int,
        load: Callable[[], Any],
    ) -> Any:
        if not fingerprint or not version:
            return load()
        key = json.dumps([fingerprint, endpoint, version, filters], sort_keys=True)
        current = self._values.get(key)
        if current and current[0] > time.monotonic():
            return copy.deepcopy(current[1])
        value = load()
        self._values[key] = (time.monotonic() + seconds, copy.deepcopy(value))
        if len(self._values) > 128:
            self._values.pop(next(iter(self._values)))
        return value

    def clear(self) -> None:
        self._values.clear()


@dataclass
class Workspace:
    api: ApiClient = field(repr=False)
    identity: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""
    cache: SessionCache = field(default_factory=SessionCache, repr=False)
    pending: PendingWrite | None = field(default=None, repr=False)
    jobs: list[str] = field(default_factory=list)
    queue_version: str | None = None
    queue_cohort: str | None = None
    cursor: dict[str, Any] = field(default_factory=dict)
    previous_cursors: list[dict[str, Any]] = field(default_factory=list)
    selected_case: str | None = None
    history_after: dict[str, int] = field(default_factory=dict)
    last_poll: dict[str, float] = field(default_factory=dict)
    job_views: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)
    last_result: dict[str, Any] | None = None
    form_cases: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)

    def authenticate(self) -> None:
        value = self.api.me()  # Authorization decisions are never read from cache.
        current = hashlib.sha256(
            json.dumps(
                {k: value[k] for k in ("actor_id", "roles", "scopes", "permission_scopes")},
                sort_keys=True,
            ).encode()
        ).hexdigest()
        if self.fingerprint and current != self.fingerprint:
            self.clear_sensitive()
        self.identity, self.fingerprint = value, current

    def allowed(self, permission: str) -> bool:
        return bool(self.identity.get("permission_scopes", {}).get(permission))

    def begin(
        self, action: str, path: str, payload: dict[str, Any] | None, **upload: Any
    ) -> PendingWrite:
        if self.pending and self.pending.state in {"PENDING", "UNKNOWN", "CONFLICT"}:
            raise ValueError("Resolve the pending action before submitting another")
        self.pending = PendingWrite(
            action, path, copy.deepcopy(payload), self.fingerprint, **upload
        )
        return self.pending

    def submit(self) -> dict[str, Any]:
        pending = self.pending
        if pending is None or pending.fingerprint != self.fingerprint:
            raise LoginRequired()
        if pending.result is not None:
            return pending.result
        if pending.state == "CONFLICT":
            raise ApiFailure("CONFLICT", status=409)
        try:
            result = self.api.json(
                "POST",
                pending.path,
                payload=pending.payload,
                key=pending.key,
                content=pending.content,
                manifest=pending.manifest,
                filename=pending.filename,
            )
        except ApiFailure as error:
            pending.state = (
                "CONFLICT"
                if error.status == 409
                else "UNKNOWN"
                if error.code == "UNAVAILABLE"
                else "REJECTED"
            )
            if error.status == 409 and pending.path.startswith("/v1/cases/"):
                pending.latest = self.api.case(UUID(pending.path.split("/")[3]))
            raise
        pending.state, pending.result = "ACKNOWLEDGED", result
        pending.content = None
        self.last_result = result
        if result.get("job_id") and result["job_id"] not in self.jobs:
            self.jobs.append(result["job_id"])
        self.cache.clear()
        if pending.path.startswith("/v1/cases/"):
            self.form_cases.pop(pending.path.split("/")[3], None)
        return result

    def poll(self, job_id: str, *, force: bool = False) -> dict[str, Any]:
        now = time.monotonic()
        if force or now - self.last_poll.get(job_id, -1000) >= self.api.config.poll_seconds:
            self.job_views[job_id] = self.api.job(UUID(job_id))
            self.last_poll[job_id] = now
        return self.job_views[job_id]

    def choose_queue(self, identity: str, cohort: str | None = None) -> None:
        if identity != self.queue_version:
            self.queue_version, self.queue_cohort = identity, cohort
            self.cursor, self.previous_cursors, self.history_after = {}, [], {}

    def clear_sensitive(self) -> None:
        self.cache.clear()
        self.pending, self.last_result, self.selected_case = None, None, None
        self.queue_version, self.queue_cohort = None, None
        self.cursor, self.previous_cursors, self.history_after = {}, [], {}
        self.jobs, self.job_views, self.last_poll = [], {}, {}
        self.form_cases.clear()

    def logout(self) -> None:
        self.clear_sensitive()
        self.identity, self.fingerprint = {}, ""
        self.api.provider.logout()
